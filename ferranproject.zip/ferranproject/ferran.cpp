public class Saludo {
    public static void main(String[] args) {
        System.out.println("Hola món i Ferran");
    }
}
